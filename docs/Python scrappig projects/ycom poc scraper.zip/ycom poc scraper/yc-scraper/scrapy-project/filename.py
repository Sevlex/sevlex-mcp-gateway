import pandas as pd
import ast
import numpy as np

print("Unpacking individual founder LinkedIn profiles...")

# 1. Load your targeted leads file
df = pd.read_csv('verseodin_yc_leads.csv')

def extract_personal_linkedin(details_str):
    try:
        # Convert the string representation of a list into an actual Python list
        details = ast.literal_eval(details_str)
        links = []
        for person in details:
            # Look for the linkedin key inside each founder's dictionary
            link = person.get('linkedin')
            if link:
                links.append(link)
        # Return the links joined by a comma if there are multiple founders
        return ", ".join(links) if links else np.nan
    except:
        return np.nan

# 2. Create the new column for personal LinkedIn URLs
df['poc_linkedin'] = df['founder_details'].apply(extract_personal_linkedin)

# 3. Drop rows that still don't have a personal LinkedIn
final_df = df.dropna(subset=['poc_linkedin'])

# 4. Save the final finalized list
output_file = 'verseodin_final_poc_list.csv'
final_df.to_csv(output_file, index=False)

print(f"Success! Extracted personal LinkedIn for {len(final_df)} founders.")
print(f"Your final outreach file is: {output_file}")