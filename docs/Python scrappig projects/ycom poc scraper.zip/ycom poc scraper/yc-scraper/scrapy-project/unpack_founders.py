import pandas as pd
import re
import numpy as np

print("Reading verseodin_yc_leads.csv...")
df = pd.read_csv('verseodin_yc_leads.csv')

def find_linkedin_regex(text):
    if pd.isna(text):
        return np.nan
    # This looks for anything matching a linkedin.com/in/ pattern
    pattern = r'https?://(?:www\.)?linkedin\.com/in/[a-zA-Z0-9_-]+'
    links = re.findall(pattern, str(text))
    # Join multiple founders with a comma, or return NaN if none found
    return ", ".join(list(set(links))) if links else np.nan

print("Force-extracting personal LinkedIn profiles...")
df['poc_linkedin'] = df['founder_details'].apply(find_linkedin_regex)

# Filter out rows that are still empty
final_df = df.dropna(subset=['poc_linkedin'])

output_file = 'verseodin_final_poc_list.csv'
final_df.to_csv(output_file, index=False)

print("-" * 30)
print(f"SUCCESS! Found personal LinkedIn URLs for {len(final_df)} founders.")
print(f"Final file: {output_file}")