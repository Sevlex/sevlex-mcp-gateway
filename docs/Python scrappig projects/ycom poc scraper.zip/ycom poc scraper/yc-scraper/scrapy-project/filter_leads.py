import pandas as pd
import numpy as np

print("Loading raw YC data...")
df = pd.read_csv('yc_founders_list.csv')

# 1. Filter for your exact target batches
target_batches = ['Winter 2021', 'Summer 2021', 'Winter 2020', 'Summer 2020']
filtered_df = df[df['batch'].isin(target_batches)].copy()

# 2. Clean the data (Drop rows where the LinkedIn URL is blank)
col_name = 'linkedin_url' 
filtered_df[col_name] = filtered_df[col_name].replace('', np.nan)
final_df = filtered_df.dropna(subset=[col_name])

# 3. Save the final list for your outreach
output_filename = 'verseodin_yc_leads.csv'
final_df.to_csv(output_filename, index=False)

print(f"Success! Filtered down to {len(final_df)} highly qualified leads and saved to {output_filename}.")